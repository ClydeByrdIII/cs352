class Main {
		public static void main(String[] args) {
				System.out.println(4);
		}
}
class Foo {
		int a;
		public int foo(int[] b) {
			Foo c;
			int g;
			g = 5;

			if(false)
				a = 4;
			else
				a = c;
			return 1;
		}
}
