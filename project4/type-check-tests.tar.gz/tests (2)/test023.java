class Main {
		public static void main(String[] args) {
				System.out.println(4);
		}
}
class Foo {
		int a;
		public int foo(int[] b) {
			b.length
			return 1;
		}
}

// NOTE: THIS TEST SHOULD FAIL. b.length IS A VALID STATEMENT.
