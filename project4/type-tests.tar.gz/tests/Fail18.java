class Main {
    public static void main(String[] a){
        System.out.println(new Class().go());
    }
}

class Class {
    public int go() {
        return this.go2();
    }

    public boolean go2() {
        return false;
    }
}
