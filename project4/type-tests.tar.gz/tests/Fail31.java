class Main {
    public static void main(String[] a){
        System.out.println(new Class().go());
    }
}

class Class {
    public int go() {
        int i;
        i[0] = 3;
        return 1;
    }
}
