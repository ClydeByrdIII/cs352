class Main {
    public static void main(String[] a){
        System.out.println(new Class().go());
    }
}

class Class {
    int i;
    int i;

    public int go() {
        return 1;
    }
}
