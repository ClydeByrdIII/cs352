class Main {
		public static void main(String[] args) {
				System.out.println(4);
		}
}
class Foo {
		int a;
		public int foo() {
			a = new Foo();
			return a;
		}
}
