class Main {
		public static void main(String[] args) {
				System.out.println(4);
		}
}
class Foo {
		int a;
		public int foo(int[] b) {
			Foo c;
			b[c] = 4;
			return a;
		}
}
